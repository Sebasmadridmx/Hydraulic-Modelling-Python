import geopandas as gpd
from shapely.ops import unary_union
from shapely.strtree import STRtree
from shapely.geometry import Polygon, MultiPolygon
import networkx as nx
import os

# ── CONFIG ───────────────────────────────────────────────────────────────────
INPUT_TAB  = '/Users/sebastianmadrid/Desktop/ICM Subcatchment Definition/Barrhead_Map/Barrhead_Opportunities.tab' # Path to the input TAB file
OUTPUT_DIR = '/Users/sebastianmadrid/Desktop/ICM Subcatchment Definition/output' # Directory to save the output shapefile
OUTPUT_SHP = os.path.join(OUTPUT_DIR, 'land_parcels.shp')
BUFFER_M   = 0.05
# ─────────────────────────────────────────────────────────────────────────────

os.makedirs(OUTPUT_DIR, exist_ok=True)

def snap_union(geom_list, buffer=BUFFER_M):
    expanded = unary_union([g.buffer(buffer) for g in geom_list])
    return expanded.buffer(-buffer)

def fill_holes(geom):
    if geom is None or geom.is_empty:
        return geom
    if geom.geom_type == 'Polygon':
        return Polygon(geom.exterior)
    if geom.geom_type == 'MultiPolygon':
        return MultiPolygon([Polygon(p.exterior) for p in geom.geoms])
    return geom

print("Reading TAB file...")
gdf = gpd.read_file(INPUT_TAB)
print(f"  {len(gdf)} features loaded. CRS: {gdf.crs}")

buildings    = gdf[gdf['OSMM_Class'] == 'OSMM Building'].copy().reset_index(drop=True)
hardstanding = gdf[gdf['OSMM_Class'] == 'OSMM Hardstanding'].copy().reset_index(drop=True)
print(f"  {len(buildings)} buildings, {len(hardstanding)} hardstanding polygons")

# ── STEP 1: Merge touching buildings (semis/terraces) ────────────────────────
print("Step 1: Merging touching buildings...")
bldg_geoms = list(buildings.geometry)
bldg_tree  = STRtree(bldg_geoms)

G = nx.Graph()
G.add_nodes_from(range(len(bldg_geoms)))

for i, geom in enumerate(bldg_geoms):
    if i % 500 == 0:
        print(f"  Building {i}/{len(bldg_geoms)}...")
    for j in bldg_tree.query(geom):
        if j <= i:
            continue
        if geom.buffer(BUFFER_M).intersects(bldg_geoms[j].buffer(BUFFER_M)):
            G.add_edge(i, j)

building_units = []
for component in nx.connected_components(G):
    indices = list(component)
    geom_list = [bldg_geoms[k] for k in indices]
    merged = snap_union(geom_list) if len(indices) > 1 else geom_list[0]
    building_units.append({'geometry': merged, 'bldg_count': len(indices)})

detached = sum(1 for u in building_units if u['bldg_count'] == 1)
print(f"  {len(bldg_geoms)} buildings -> {len(building_units)} units "
      f"({detached} detached, {len(building_units)-detached} semi/terrace groups)")

# ── STEP 2: Match building units to hardstanding ─────────────────────────────
print("Step 2: Matching to hardstanding...")
hs_geoms    = list(hardstanding.geometry)
hs_tree     = STRtree(hs_geoms)
hs_claim    = {}
unit_hs_map = {i: [] for i in range(len(building_units))}

for i, unit in enumerate(building_units):
    unit_geom  = unit['geometry']
    candidates = hs_tree.query(unit_geom)
    for j in candidates:
        if j in hs_claim:
            continue
        hs_geom = hs_geoms[j]
        if (unit_geom.touches(hs_geom)
                or unit_geom.intersects(hs_geom)
                or unit_geom.within(hs_geom)
                or hs_geom.within(unit_geom)):
            hs_claim[j] = i
            unit_hs_map[i].append(j)

merged_geoms  = []
merged_labels = []

for i, unit in enumerate(building_units):
    hs_indices = unit_hs_map[i]
    if hs_indices:
        parts = [unit['geometry']] + [hs_geoms[j] for j in hs_indices]
        merged_geoms.append(fill_holes(unary_union(parts)))
        merged_labels.append('Building+Hardstanding')
    else:
        merged_geoms.append(unit['geometry'])
        merged_labels.append('OSMM Building')

# ── STEP 3: Unclaimed hardstanding ───────────────────────────────────────────
print("Step 3: Adding unclaimed hardstanding...")
unclaimed = 0
for j, hs_geom in enumerate(hs_geoms):
    if j not in hs_claim:
        merged_geoms.append(fill_holes(hs_geom))
        merged_labels.append('OSMM Hardstanding')
        unclaimed += 1
print(f"  {unclaimed} unclaimed hardstanding parcels")

# ── STEP 4: Subtract overlaps — larger parcel wins, smaller gets clipped ─────
print("Step 4: Resolving overlaps...")
result = gpd.GeoDataFrame({
    'parcel_id':  range(1, len(merged_geoms) + 1),
    'class_type': merged_labels,
    'geometry':   merged_geoms
}, crs=gdf.crs)

result = result[result.geometry.is_valid & ~result.geometry.is_empty].copy()
result['area_m2'] = result.geometry.area
result = result.sort_values('area_m2', ascending=False).reset_index(drop=True)

geoms_out = list(result.geometry)
tree_out  = STRtree(geoms_out)

print("  Clipping smaller overlapping parcels...")
for i in range(len(geoms_out)):
    if i % 500 == 0:
        print(f"  Parcel {i}/{len(geoms_out)}...")
    if geoms_out[i] is None or geoms_out[i].is_empty:
        continue
    candidates = tree_out.query(geoms_out[i])
    for j in candidates:
        if j <= i or geoms_out[j] is None or geoms_out[j].is_empty:
            continue
        if geoms_out[i].intersects(geoms_out[j]):
            overlap = geoms_out[i].intersection(geoms_out[j])
            if not overlap.is_empty and overlap.area > 0.01:  # ignore slivers < 1cm²
                # Subtract overlap from the smaller parcel (j, since sorted by area desc)
                clipped = geoms_out[j].difference(geoms_out[i])
                geoms_out[j] = clipped if not clipped.is_empty else None

result['geometry'] = geoms_out
result = result[result.geometry.notna() & ~result.geometry.is_empty].copy()
result = result[result.geometry.is_valid].copy()
result = result.reset_index(drop=True)
result['parcel_id'] = range(1, len(result) + 1)
result['area_m2']   = result.geometry.area.round(2)

result.to_file(OUTPUT_SHP)
print(f"\nDone. {len(result)} parcels written to:\n  {OUTPUT_SHP}")
print(result['class_type'].value_counts().to_string())